const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 3000);
const HOST_KEY = process.env.HOST_KEY || 'change-me-before-deploying';
const root = path.join(__dirname, 'public');
const dataFile = path.join(__dirname, 'data', 'results.json');
fs.mkdirSync(path.dirname(dataFile), { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, '[]');
const headers = { 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; frame-ancestors 'self'", 'X-Content-Type-Options':'nosniff', 'Referrer-Policy':'no-referrer', 'Cache-Control':'no-store' };
function send(res,status,body,type='application/json; charset=utf-8'){res.writeHead(status,{...headers,'Content-Type':type});res.end(type.startsWith('application/json')?JSON.stringify(body):body)}
function load(){try{return JSON.parse(fs.readFileSync(dataFile,'utf8'))}catch{return []}}
function save(rows){const tmp=dataFile+'.tmp';fs.writeFileSync(tmp,JSON.stringify(rows,null,2));fs.renameSync(tmp,dataFile)}
function body(req){return new Promise((ok,bad)=>{let d='';req.on('data',c=>{d+=c;if(d.length>1e6)req.destroy()});req.on('end',()=>{try{ok(JSON.parse(d||'{}'))}catch(e){bad(e)}});req.on('error',bad)})}
function cleanText(v,n=60){return String(v||'').replace(/[<>]/g,'').trim().slice(0,n)}
const server=http.createServer(async(req,res)=>{try{
 const u=new URL(req.url,'http://local');
 if(u.pathname==='/api/health') return send(res,200,{ok:true});
 if(u.pathname==='/api/results'&&req.method==='GET') return send(res,200,load());
 if(u.pathname==='/api/results'&&req.method==='POST'){
  const x=await body(req); const required=['name','actualAge','culturalAge','spiritYear','persona','scores','answers','comment'];
  if(required.some(k=>x[k]===undefined)) return send(res,400,{error:'Incomplete result'});
  const row={id:crypto.randomUUID(),name:cleanText(x.name),actualAge:Number(x.actualAge),culturalAge:Number(x.culturalAge),gap:Number(x.culturalAge)-Number(x.actualAge),spiritYear:Number(x.spiritYear),persona:cleanText(x.persona),nostalgia:Number(x.nostalgia),adaptability:Number(x.adaptability),scores:x.scores,answers:x.answers,comment:cleanText(x.comment,260),createdAt:new Date().toISOString()};
  if(!row.name||row.actualAge<18||row.actualAge>99) return send(res,400,{error:'Invalid name or age'});
  let rows=load().filter(r=>r.name.toLowerCase()!==row.name.toLowerCase()); rows.push(row); save(rows); return send(res,201,row);
 }
 if(u.pathname==='/api/results'&&req.method==='DELETE'){
  if(req.headers['x-host-key']!==HOST_KEY) return send(res,403,{error:'Invalid host key'}); save([]); return send(res,200,{ok:true});
 }
 let rel=u.pathname==='/'?'index.html':u.pathname.slice(1); rel=path.normalize(rel).replace(/^(\.\.(\/|\\|$))+/, ''); const f=path.join(root,rel);
 if(!f.startsWith(root)||!fs.existsSync(f)||fs.statSync(f).isDirectory()) return send(res,404,'Not found','text/plain; charset=utf-8');
 const ext=path.extname(f); const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'}; return send(res,200,fs.readFileSync(f),types[ext]||'application/octet-stream');
}catch(e){console.error(e);send(res,500,{error:'Server error'})}});
server.listen(PORT,()=>console.log(`Cultural Age Quiz running on http://localhost:${PORT}`));

# Cultural Age Quiz

A small, centralised website for a 10–15 person team. One Node.js process serves the quiz and stores results centrally in `data/results.json`.

## Run locally

1. Install Node.js 20 or later.
2. Open a terminal in this folder.
3. Set a host key and start:

```bash
HOST_KEY="choose-a-private-key" npm start
```

On Windows PowerShell:

```powershell
$env:HOST_KEY="choose-a-private-key"
npm start
```

Open `http://localhost:3000`.

## Deploy to Azure App Service

- Create a Linux Node.js App Service.
- Deploy this entire folder as a ZIP or through Visual Studio Code/GitHub.
- Set the App Service application setting `HOST_KEY` to a private value.
- The app listens on Azure's `PORT` environment variable automatically.

## Important persistence note

`data/results.json` is suitable for a small event and a single running instance. Do not enable multiple instances or autoscaling because separate instances may not share the same local file. For durable long-term use, replace the `load()` / `save()` functions in `server.js` with Azure Table Storage, Cosmos DB, SQL, or another central database.

## Host workflow

- Share the deployed website URL with participants.
- Each completed quiz is saved automatically.
- Open **Host Dashboard** and click **Refresh**.
- The dashboard shows five standout profiles and everyone at a glance.
- Use **Clear Results** and enter the configured `HOST_KEY` before the event begins or after testing.
